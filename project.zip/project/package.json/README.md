# Shopify Product Page Enhancement App

This app provides additional functionality for Shopify product pages, including the ability to add extra images.

## Features
- Upload additional images to product pages.
- Retrieve images for specific products.
- Easy-to-use frontend interface with Polaris.

## Setup Instructions

1. Clone the repository:
